Makefile can be run as usual.

CLI Instructions:
$make clean
$make
./main